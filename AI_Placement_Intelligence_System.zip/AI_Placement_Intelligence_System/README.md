# AI-Powered Smart Campus Placement & Career Intelligence System

A full-stack Data Science web application that helps B.Tech students understand their
placement readiness, discover suitable career roles, identify skill gaps, follow a
personalized learning roadmap, and track their progress over time — while giving
placement officers a dashboard to identify students who may need extra support.

---

## Problem Statement

Many students don't know:
- Whether they are ready for placements
- Which skills companies expect
- Which career role suits their current profile
- What they should learn next
- How to improve their placement chances

This system solves these problems using Machine Learning, data analytics,
recommendation logic, and interactive dashboards — all running locally, no paid APIs required.

---

## Features

- 🔐 **Student & Admin Login** — secure password hashing with bcrypt
- 👤 **Student Profile** — detailed profile covering skills, academics, and experience
- 📊 **Placement Readiness Score** — 0–100 score with category breakdown
- 🤖 **ML Placement Prediction** — Random Forest / Logistic Regression / Gradient Boosting, best model auto-selected
- 🎯 **Career Role Recommendations** — matched against 10 common tech career roles
- 🧠 **Skill Gap Analysis** — student skills vs. role-required skills
- 📚 **Personalized Learning Roadmap** — prioritized, trackable (Not Started / In Progress / Completed)
- 📄 **Resume Analyzer** — PDF upload, skill detection, resume score, suggestions
- 🏢 **Company Insights** — educational skill-match against common recruiter profiles (clearly labeled as non-official)
- 🎤 **Mock Interview Preparation** — role-based technical, Python, SQL, HR, and project questions
- 📈 **Progress Tracker** — historical readiness score chart + roadmap completion chart
- 👨‍💼 **Admin Analytics Dashboard** — branch-wise readiness, skill distribution, at-risk student identification, CSV export

---

## Technologies Used

| Layer | Technology |
|---|---|
| Frontend/UI | Streamlit |
| Data handling | Pandas, NumPy |
| Machine Learning | Scikit-learn (Random Forest, Logistic Regression, Gradient Boosting) |
| Charts | Plotly |
| Model persistence | Joblib |
| Database | SQLite |
| Resume parsing | PyPDF2 |
| Auth | bcrypt |

---

## Project Architecture

```
AI_Placement_Intelligence_System/
│
├── app.py                      # Home page, login, registration
├── requirements.txt
├── README.md
│
├── data/                       # Auto-generated synthetic datasets
│   ├── students_dataset.csv
│   ├── company_skills.csv
│   └── job_roles.csv
│
├── models/                     # Auto-generated trained ML artifacts
│   ├── placement_model.pkl
│   ├── preprocessor.pkl
│   └── training_results.pkl
│
├── database/                   # Auto-generated SQLite database
│   └── placement_system.db
│
├── pages/                      # Streamlit multipage app pages
│   ├── 1_Student_Profile.py
│   ├── 2_Placement_Predictor.py
│   ├── 3_Career_Recommendations.py
│   ├── 4_Skill_Gap_Analysis.py
│   ├── 5_Learning_Roadmap.py
│   ├── 6_Resume_Analyzer.py
│   ├── 7_Company_Insights.py
│   ├── 8_Interview_Preparation.py
│   ├── 9_Progress_Tracker.py
│   └── 10_Admin_Dashboard.py
│
└── utils/
    ├── database.py              # SQLite tables, auth, CRUD
    ├── dataset_generator.py     # Synthetic data generation
    ├── ml_model.py               # ML training, evaluation, prediction
    ├── recommendation_engine.py  # Career role matching
    └── skill_analysis.py         # Readiness score, skill gap, resume, company match, interview Qs
```

The dataset, SQLite database, and ML model are all generated **automatically on first run** —
you do not need to create or provide anything manually.

---

## Installation

1. **Clone or download** this project folder, then open it in VS Code.

2. **(Recommended) Create a virtual environment:**
   ```bash
   python -m venv venv
   venv\Scripts\activate        # Windows
   source venv/bin/activate     # macOS/Linux
   ```

3. **Install dependencies:**
   ```bash
   pip install -r requirements.txt
   ```

---

## How to Run

```bash
streamlit run app.py
```

Then open the URL Streamlit prints in your terminal (usually `http://localhost:8501`).

**On first run**, the app automatically:
- Creates the SQLite database and its tables
- Generates a synthetic dataset of 1,000 student records
- Trains and saves the ML model (Random Forest, Logistic Regression, Gradient Boosting compared)
- Creates a default admin account

### Default Login

| Role | Username | Password |
|---|---|---|
| Admin | `admin` | `admin123` |
| Student | *(register your own from the "Register" tab)* | — |

---

## Usage Flow

1. Register a student account (or log in as admin).
2. As a student: fill out your **Student Profile** first — every other page depends on it.
3. Explore **Placement Predictor**, **Career Recommendations**, **Skill Gap Analysis**, **Learning Roadmap**, **Resume Analyzer**, **Company Insights**, and **Interview Preparation**.
4. Check **Progress Tracker** after running a few predictions to see your history.
5. As admin: log in with the default admin account to view **Admin Dashboard** analytics across all registered students.

---

## Screenshots

*(Add screenshots here after running the app locally — e.g. Home page, Placement Predictor, Admin Dashboard.)*

---

## Common Errors & Solutions

| Error | Solution |
|---|---|
| `ModuleNotFoundError: No module named 'streamlit'` | Run `pip install -r requirements.txt` |
| App opens but pages sidebar is empty | Make sure you're running `streamlit run app.py` from the project root, not from inside `pages/` |
| `KeyError` on Placement Predictor | Make sure you've saved your Student Profile first |
| PDF upload fails on Resume Analyzer | Make sure the file is a text-based PDF, not a scanned image |
| Database looks empty after deleting `database/placement_system.db` | This is expected — it will regenerate with just the default admin account on next run |

---

## Important Notes

- All student data in the shipped dataset is **synthetic** — no real student personal data is used anywhere.
- The **Company Insights** feature is explicitly labeled as an **educational skill-match recommendation**, not an official hiring requirement from any company.
- The **Early Support** feature deliberately avoids negative labeling (e.g., never uses the word "failure") and instead shows supportive, actionable messages.

---

## Future Improvements

- Add email/OTP-based verification for registration
- Expand the company database with real, sourced, and cited skill requirements
- Add NLP-based resume-to-job-description matching
- Add a chatbot-style AI mentor for personalized guidance
- Deploy to Streamlit Community Cloud for public access
