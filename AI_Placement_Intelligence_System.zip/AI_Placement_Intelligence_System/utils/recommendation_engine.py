"""
recommendation_engine.py
-------------------------
Recommends suitable career roles for a student based on their skills,
using the required-skills data from data/job_roles.csv.
"""

from utils.skill_analysis import load_job_roles, get_student_known_skills, SKILL_FIELD_MAP


def recommend_career_roles(student: dict, top_n=5, threshold=50):
    """
    Score every career role in job_roles.csv against the student's skill
    profile and return the top N matches with a match percentage and reason.
    """
    roles_df = load_job_roles()
    known_skills = get_student_known_skills(student, threshold)
    known_lower = {s.lower() for s in known_skills}

    recommendations = []
    for _, row in roles_df.iterrows():
        required_skills = [s.strip() for s in row["required_skills"].split(",")]
        matched = [s for s in required_skills if s.lower() in known_lower]
        match_percentage = round((len(matched) / len(required_skills)) * 100, 1) if required_skills else 0

        if matched:
            reason = f"Matches on {', '.join(matched)}."
        else:
            reason = "Limited overlap with your current skill profile — consider this a stretch goal."

        recommendations.append({
            "role": row["role"],
            "match_percentage": match_percentage,
            "matched_skills": matched,
            "required_skills": required_skills,
            "reason": reason,
        })

    recommendations.sort(key=lambda r: r["match_percentage"], reverse=True)
    return recommendations[:top_n]
