"""
dataset_generator.py
---------------------
Generates realistic SYNTHETIC datasets used to train the ML model and power
the Company Insights feature. No real student data is used anywhere.

Creates:
    data/students_dataset.csv   -> 1000 synthetic student records
    data/company_skills.csv     -> example company skill expectations
    data/job_roles.csv          -> required skills per career role
"""

import os
import numpy as np
import pandas as pd

DATA_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "data")

BRANCHES = ["CSE", "CSE-DS", "IT", "ECE", "EEE", "MECH"]


def generate_student_dataset(n=1000, seed=42):
    """Generate a synthetic student dataset and save it to data/students_dataset.csv."""
    os.makedirs(DATA_DIR, exist_ok=True)
    rng = np.random.default_rng(seed)

    student_id = np.arange(1, n + 1)
    branch = rng.choice(BRANCHES, size=n, p=[0.35, 0.20, 0.15, 0.15, 0.10, 0.05])
    year = rng.choice([1, 2, 3, 4], size=n, p=[0.15, 0.20, 0.30, 0.35])
    cgpa = np.clip(rng.normal(7.3, 0.9, n), 4.0, 10.0).round(2)

    python_skill = rng.integers(0, 101, n)
    java_skill = rng.integers(0, 101, n)
    sql_skill = rng.integers(0, 101, n)
    dsa_skill = rng.integers(0, 101, n)
    machine_learning_skill = rng.integers(0, 101, n)

    communication_score = rng.integers(30, 101, n)
    aptitude_score = rng.integers(30, 101, n)
    coding_score = rng.integers(20, 101, n)

    project_count = rng.poisson(2.2, n).clip(0, 10)
    certification_count = rng.poisson(1.5, n).clip(0, 8)
    internship_experience = rng.choice([0, 1], size=n, p=[0.7, 0.3])
    attendance_percentage = np.clip(rng.normal(82, 8, n), 40, 100).round(1)

    # Build a composite "readiness signal" to make placement_status realistically
    # correlated with the underlying skills, instead of pure random noise.
    readiness_signal = (
        0.15 * cgpa * 10
        + 0.15 * python_skill
        + 0.10 * dsa_skill
        + 0.10 * sql_skill
        + 0.10 * machine_learning_skill
        + 0.15 * coding_score
        + 0.10 * communication_score
        + 0.10 * aptitude_score
        + 5 * project_count
        + 4 * certification_count
        + 10 * internship_experience
        + 0.05 * attendance_percentage
    )
    # Normalize to 0-100 and add small random noise so the target isn't a
    # deterministic function of the features (that would make ML trivial).
    readiness_signal = (readiness_signal - readiness_signal.min()) / (
        readiness_signal.max() - readiness_signal.min()
    ) * 100
    noise = rng.normal(0, 8, n)
    final_signal = readiness_signal + noise

    threshold = np.percentile(final_signal, 45)  # ~55% placed, realistic for a mixed dataset
    placement_status = np.where(final_signal >= threshold, "Placed", "Not Placed")

    df = pd.DataFrame({
        "student_id": student_id,
        "branch": branch,
        "year": year,
        "cgpa": cgpa,
        "python_skill": python_skill,
        "java_skill": java_skill,
        "sql_skill": sql_skill,
        "dsa_skill": dsa_skill,
        "machine_learning_skill": machine_learning_skill,
        "communication_score": communication_score,
        "aptitude_score": aptitude_score,
        "coding_score": coding_score,
        "project_count": project_count,
        "certification_count": certification_count,
        "internship_experience": internship_experience,
        "attendance_percentage": attendance_percentage,
        "placement_status": placement_status,
    })

    out_path = os.path.join(DATA_DIR, "students_dataset.csv")
    df.to_csv(out_path, index=False)
    return out_path


def generate_company_dataset():
    """Generate data/company_skills.csv - example educational skill-match data."""
    os.makedirs(DATA_DIR, exist_ok=True)

    companies = [
        {
            "company_name": "TCS",
            "common_job_roles": "Software Developer, Data Analyst",
            "required_skills": "Python, SQL, Communication, Aptitude",
            "preferred_skills": "Java, Cloud Basics",
            "aptitude_importance": "High",
            "communication_importance": "High",
        },
        {
            "company_name": "Infosys",
            "common_job_roles": "Software Engineer, Systems Engineer",
            "required_skills": "Java, DSA, Communication, Aptitude",
            "preferred_skills": "Python, SQL, Cloud",
            "aptitude_importance": "High",
            "communication_importance": "Medium",
        },
        {
            "company_name": "Wipro",
            "common_job_roles": "Project Engineer, Data Analyst",
            "required_skills": "Python, SQL, Communication",
            "preferred_skills": "Java, Machine Learning",
            "aptitude_importance": "Medium",
            "communication_importance": "High",
        },
        {
            "company_name": "Accenture",
            "common_job_roles": "Application Developer, Data Analyst",
            "required_skills": "Python, SQL, Communication, DSA",
            "preferred_skills": "Cloud, Machine Learning",
            "aptitude_importance": "Medium",
            "communication_importance": "High",
        },
        {
            "company_name": "Cognizant",
            "common_job_roles": "Programmer Analyst",
            "required_skills": "Java, SQL, DSA, Communication",
            "preferred_skills": "Python, Cloud Basics",
            "aptitude_importance": "Medium",
            "communication_importance": "Medium",
        },
        {
            "company_name": "Capgemini",
            "common_job_roles": "Software Engineer, Data Analyst",
            "required_skills": "Python, Java, Communication",
            "preferred_skills": "SQL, Cloud, Machine Learning",
            "aptitude_importance": "Medium",
            "communication_importance": "High",
        },
        {
            "company_name": "Deloitte",
            "common_job_roles": "Business/Data Analyst",
            "required_skills": "SQL, Communication, Aptitude, Python",
            "preferred_skills": "Machine Learning, Cloud",
            "aptitude_importance": "High",
            "communication_importance": "High",
        },
    ]

    df = pd.DataFrame(companies)
    out_path = os.path.join(DATA_DIR, "company_skills.csv")
    df.to_csv(out_path, index=False)
    return out_path


def generate_job_roles_dataset():
    """Generate data/job_roles.csv - required skills per career role."""
    os.makedirs(DATA_DIR, exist_ok=True)

    roles = [
        {"role": "Data Analyst", "required_skills": "Python, SQL, Excel, Data Visualization, Statistics"},
        {"role": "Data Scientist", "required_skills": "Python, Machine Learning, Statistics, SQL, Data Visualization"},
        {"role": "Machine Learning Engineer", "required_skills": "Python, Machine Learning, DSA, SQL, Cloud"},
        {"role": "Data Engineer", "required_skills": "Python, SQL, Cloud, DSA, ETL"},
        {"role": "Software Developer", "required_skills": "Java, DSA, Python, Git, Communication"},
        {"role": "Python Developer", "required_skills": "Python, DSA, SQL, Git, OOP"},
        {"role": "Business Analyst", "required_skills": "SQL, Communication, Excel, Data Visualization, Aptitude"},
        {"role": "AI Engineer", "required_skills": "Python, Machine Learning, DSA, Statistics, Cloud"},
        {"role": "Cloud Engineer", "required_skills": "Cloud, Python, Linux, Networking, DSA"},
        {"role": "Cybersecurity Analyst", "required_skills": "Networking, Linux, Python, Security Fundamentals, Communication"},
    ]

    df = pd.DataFrame(roles)
    out_path = os.path.join(DATA_DIR, "job_roles.csv")
    df.to_csv(out_path, index=False)
    return out_path


def ensure_datasets_exist():
    """Generate all datasets only if they don't already exist. Called automatically by the app."""
    students_path = os.path.join(DATA_DIR, "students_dataset.csv")
    company_path = os.path.join(DATA_DIR, "company_skills.csv")
    roles_path = os.path.join(DATA_DIR, "job_roles.csv")

    if not os.path.exists(students_path):
        generate_student_dataset()
    if not os.path.exists(company_path):
        generate_company_dataset()
    if not os.path.exists(roles_path):
        generate_job_roles_dataset()


if __name__ == "__main__":
    # Allows running this file directly for testing: python utils/dataset_generator.py
    print("Generating students dataset ->", generate_student_dataset())
    print("Generating company dataset ->", generate_company_dataset())
    print("Generating job roles dataset ->", generate_job_roles_dataset())
