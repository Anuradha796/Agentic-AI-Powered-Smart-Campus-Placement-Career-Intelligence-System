"""
ml_model.py
-----------
Complete Machine Learning pipeline for placement prediction.

Steps performed:
    1. Load dataset
    2. Handle missing values
    3. Encode categorical features (branch)
    4. Scale numeric features
    5. Train/test split
    6. Train multiple models (Random Forest, Logistic Regression, Gradient Boosting)
    7. Evaluate + compare models
    8. Save the best model + preprocessing objects with Joblib

If the model file does not exist, train_and_save_model() is called
automatically the first time the app needs a prediction.
"""

import os
import joblib
import numpy as np
import pandas as pd

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, confusion_matrix

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_PATH = os.path.join(BASE_DIR, "data", "students_dataset.csv")
MODEL_DIR = os.path.join(BASE_DIR, "models")
MODEL_PATH = os.path.join(MODEL_DIR, "placement_model.pkl")
PREPROCESSOR_PATH = os.path.join(MODEL_DIR, "preprocessor.pkl")

FEATURE_COLUMNS = [
    "branch_encoded", "year", "cgpa", "python_skill", "java_skill", "sql_skill",
    "dsa_skill", "machine_learning_skill", "communication_score", "aptitude_score",
    "coding_score", "project_count", "certification_count", "internship_experience",
    "attendance_percentage",
]


def _build_features(df: pd.DataFrame, branch_encoder: LabelEncoder = None, fit_encoder=False):
    """Encode the branch column and assemble the feature matrix."""
    df = df.copy()
    df = df.fillna(df.median(numeric_only=True))  # handle missing numeric values

    if fit_encoder:
        branch_encoder = LabelEncoder()
        df["branch_encoded"] = branch_encoder.fit_transform(df["branch"].astype(str))
    else:
        # Handle unseen branch categories gracefully at prediction time
        known_classes = set(branch_encoder.classes_)
        df["branch"] = df["branch"].astype(str).apply(lambda b: b if b in known_classes else branch_encoder.classes_[0])
        df["branch_encoded"] = branch_encoder.transform(df["branch"])

    X = df[FEATURE_COLUMNS]
    return X, branch_encoder


def train_and_save_model():
    """
    Train Random Forest, Logistic Regression, and Gradient Boosting models,
    compare them on accuracy/precision/recall/F1, and save the best one.

    Returns a dict of evaluation metrics for all models (used for display in the app).
    """
    if not os.path.exists(DATA_PATH):
        from utils.dataset_generator import generate_student_dataset
        generate_student_dataset()

    df = pd.read_csv(DATA_PATH)
    df = df.dropna(subset=["placement_status"])

    target_encoder = LabelEncoder()
    y = target_encoder.fit_transform(df["placement_status"])  # Placed=1, Not Placed=0 (alphabetical)

    X, branch_encoder = _build_features(df, fit_encoder=True)

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y
    )

    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)

    models = {
        "Random Forest": RandomForestClassifier(n_estimators=200, max_depth=8, random_state=42),
        "Logistic Regression": LogisticRegression(max_iter=1000, random_state=42),
        "Gradient Boosting": GradientBoostingClassifier(n_estimators=150, random_state=42),
    }

    results = {}
    best_model_name = None
    best_score = -1
    best_model_obj = None

    for name, model in models.items():
        model.fit(X_train_scaled, y_train)
        preds = model.predict(X_test_scaled)

        acc = accuracy_score(y_test, preds)
        prec = precision_score(y_test, preds, zero_division=0)
        rec = recall_score(y_test, preds, zero_division=0)
        f1 = f1_score(y_test, preds, zero_division=0)
        cm = confusion_matrix(y_test, preds).tolist()

        results[name] = {
            "accuracy": round(acc, 4),
            "precision": round(prec, 4),
            "recall": round(rec, 4),
            "f1_score": round(f1, 4),
            "confusion_matrix": cm,
        }

        if f1 > best_score:
            best_score = f1
            best_model_name = name
            best_model_obj = model

    os.makedirs(MODEL_DIR, exist_ok=True)
    joblib.dump(best_model_obj, MODEL_PATH)
    joblib.dump(
        {"scaler": scaler, "branch_encoder": branch_encoder, "target_encoder": target_encoder},
        PREPROCESSOR_PATH,
    )

    results["best_model"] = best_model_name
    # Save results alongside the model so the app can display them without retraining
    joblib.dump(results, os.path.join(MODEL_DIR, "training_results.pkl"))

    return results


def load_model():
    """
    Load the trained model + preprocessor. If they don't exist yet,
    train them automatically first (as required: automatic training on first run).
    """
    if not os.path.exists(MODEL_PATH) or not os.path.exists(PREPROCESSOR_PATH):
        train_and_save_model()

    model = joblib.load(MODEL_PATH)
    preprocessor = joblib.load(PREPROCESSOR_PATH)
    return model, preprocessor


def get_training_results():
    """Load saved training metrics, training the model first if necessary."""
    results_path = os.path.join(MODEL_DIR, "training_results.pkl")
    if not os.path.exists(results_path):
        return train_and_save_model()
    return joblib.load(results_path)


def predict_placement(student_features: dict):
    """
    Predict placement probability for a single student.

    student_features must contain keys matching student_profiles columns:
    branch, year, cgpa, python_skill, java_skill, sql_skill, dsa_skill,
    machine_learning_skill, communication_score, aptitude_score, coding_score,
    project_count, certification_count, internship_experience, attendance_percentage

    Returns: dict with placement_probability (0-100), predicted_label, risk_level
    """
    model, preprocessor = load_model()
    scaler = preprocessor["scaler"]
    branch_encoder = preprocessor["branch_encoder"]
    target_encoder = preprocessor["target_encoder"]

    student_features = dict(student_features)  # avoid mutating caller's dict

    # Be robust to being passed a raw student_profiles row, which stores
    # certifications as free text rather than a pre-counted number.
    if "certification_count" not in student_features or student_features["certification_count"] is None:
        certs_text = student_features.get("certifications") or ""
        student_features["certification_count"] = (
            len([c for c in certs_text.split(",") if c.strip()]) if certs_text else 0
        )

    # Fill any other missing/None numeric fields with 0 so a partially-filled
    # profile never crashes the prediction.
    for col in FEATURE_COLUMNS:
        source_key = "branch" if col == "branch_encoded" else col
        if source_key not in student_features or student_features[source_key] is None:
            if source_key != "branch":
                student_features[source_key] = 0

    df = pd.DataFrame([student_features])
    X, _ = _build_features(df, branch_encoder=branch_encoder, fit_encoder=False)
    X_scaled = scaler.transform(X)

    proba = model.predict_proba(X_scaled)[0]
    # Find which index corresponds to "Placed"
    placed_index = list(target_encoder.classes_).index("Placed")
    placement_probability = round(float(proba[placed_index]) * 100, 2)

    if placement_probability >= 70:
        risk_level = "Low Risk"
        probability_label = "High Placement Probability"
    elif placement_probability >= 40:
        risk_level = "Medium Risk"
        probability_label = "Medium Placement Probability"
    else:
        risk_level = "High Risk"
        probability_label = "Low Placement Probability"

    return {
        "placement_probability": placement_probability,
        "probability_label": probability_label,
        "risk_level": risk_level,
    }


if __name__ == "__main__":
    # Allows direct testing: python utils/ml_model.py
    print("Training model...")
    res = train_and_save_model()
    for name, metrics in res.items():
        if name != "best_model":
            print(name, metrics)
    print("Best model:", res["best_model"])

    sample = {
        "branch": "CSE", "year": 3, "cgpa": 8.1, "python_skill": 75, "java_skill": 40,
        "sql_skill": 65, "dsa_skill": 70, "machine_learning_skill": 60,
        "communication_score": 70, "aptitude_score": 72, "coding_score": 68,
        "project_count": 3, "certification_count": 2, "internship_experience": 1,
        "attendance_percentage": 88.0,
    }
    print("Sample prediction:", predict_placement(sample))
