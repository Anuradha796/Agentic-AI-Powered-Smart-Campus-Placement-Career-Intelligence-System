"""
skill_analysis.py
------------------
Core non-ML analytics logic:
    - Placement Readiness Score calculation
    - Skill Gap Analysis (student vs required skills for a role)
    - Resume text analysis (PDF parsing + keyword/skill detection)
    - Student strength identification
    - Early support / at-risk identification (educational framing, no negative labels)
    - Interview question bank
"""

import re
import os
import pandas as pd
import PyPDF2

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_DIR = os.path.join(BASE_DIR, "data")

# A student's numeric skill fields map to a "skill name" used across the app.
SKILL_FIELD_MAP = {
    "Python": "python_skill",
    "Java": "java_skill",
    "SQL": "sql_skill",
    "DSA": "dsa_skill",
    "Machine Learning": "machine_learning_skill",
}

# Master list of keywords the resume analyzer looks for.
RESUME_SKILL_KEYWORDS = [
    "python", "java", "sql", "machine learning", "data structures", "algorithms",
    "pandas", "numpy", "scikit-learn", "tensorflow", "streamlit", "excel",
    "power bi", "tableau", "cloud", "aws", "azure", "git", "github", "html",
    "css", "javascript", "statistics", "data visualization", "communication",
]

RESUME_SECTION_KEYWORDS = {
    "Contact Information": ["email", "phone", "linkedin", "@"],
    "Skills": ["skills", "technical skills"],
    "Projects": ["project", "projects"],
    "Certifications": ["certification", "certifications", "certified"],
    "Experience": ["internship", "experience", "work experience"],
}


# ---------------------------------------------------------------------------
# PLACEMENT READINESS SCORE
# ---------------------------------------------------------------------------

def calculate_readiness_score(student: dict):
    """
    Calculate an overall 0-100 Placement Readiness Score plus category-wise
    sub-scores, based on technical skills, programming, CGPA, projects,
    certifications, aptitude, communication, and internship experience.
    """
    technical = (student.get("dsa_skill", 0) + student.get("machine_learning_skill", 0)) / 2
    programming = (
        student.get("python_skill", 0) + student.get("java_skill", 0) + student.get("sql_skill", 0)
    ) / 3
    communication = student.get("communication_score", 0)
    aptitude = student.get("aptitude_score", 0)

    project_score = min(student.get("project_count", 0) * 20, 100)
    certification_score = min(student.get("certification_count", 0) * 20, 100)
    projects_combined = (project_score + certification_score) / 2

    cgpa_score = min((student.get("cgpa", 0) / 10) * 100, 100)
    internship_bonus = 10 if student.get("internship_experience", 0) else 0

    category_scores = {
        "Technical Skills": round(technical, 1),
        "Programming": round(programming, 1),
        "Communication": round(communication, 1),
        "Aptitude": round(aptitude, 1),
        "Projects": round(projects_combined, 1),
    }

    overall = (
        0.25 * technical
        + 0.20 * programming
        + 0.15 * communication
        + 0.15 * aptitude
        + 0.15 * projects_combined
        + 0.10 * cgpa_score
    ) + internship_bonus

    overall = round(min(overall, 100), 1)

    if overall >= 75:
        strengths = ["Strong overall readiness", "Competitive technical profile"]
    elif overall >= 50:
        strengths = ["Solid foundation with room to grow"]
    else:
        strengths = ["Early-stage profile — steady improvement will help a lot"]

    improvement_areas = [k for k, v in category_scores.items() if v < 60]

    return {
        "overall_score": overall,
        "category_scores": category_scores,
        "strengths": strengths,
        "improvement_areas": improvement_areas,
    }


# ---------------------------------------------------------------------------
# SKILL GAP ANALYSIS
# ---------------------------------------------------------------------------

def load_job_roles():
    path = os.path.join(DATA_DIR, "job_roles.csv")
    if not os.path.exists(path):
        from utils.dataset_generator import generate_job_roles_dataset
        generate_job_roles_dataset()
    return pd.read_csv(path)


def get_student_known_skills(student: dict, threshold=50):
    """Return a list of skill names the student is reasonably proficient in (score >= threshold)."""
    known = []
    for skill_name, field in SKILL_FIELD_MAP.items():
        if student.get(field, 0) >= threshold:
            known.append(skill_name)
    return known


def skill_gap_for_role(student: dict, role_name: str, threshold=50):
    """
    Compare a student's known skills against a role's required skills.
    Returns dict with available, missing, and match percentage.
    """
    roles_df = load_job_roles()
    row = roles_df[roles_df["role"] == role_name]
    if row.empty:
        return {"available": [], "missing": [], "match_percentage": 0}

    required_skills = [s.strip() for s in row.iloc[0]["required_skills"].split(",")]
    known_skills = get_student_known_skills(student, threshold)

    # Case-insensitive comparison
    known_lower = {s.lower() for s in known_skills}
    available = [s for s in required_skills if s.lower() in known_lower]
    missing = [s for s in required_skills if s.lower() not in known_lower]

    match_percentage = round((len(available) / len(required_skills)) * 100, 1) if required_skills else 0

    return {"available": available, "missing": missing, "match_percentage": match_percentage}


# ---------------------------------------------------------------------------
# STUDENT STRENGTH IDENTIFICATION
# ---------------------------------------------------------------------------

def identify_strengths_and_gaps(student: dict):
    """Automatically identify a student's top strengths and areas to improve."""
    scores = {
        "Python skills": student.get("python_skill", 0),
        "Java skills": student.get("java_skill", 0),
        "SQL skills": student.get("sql_skill", 0),
        "DSA skills": student.get("dsa_skill", 0),
        "Machine Learning skills": student.get("machine_learning_skill", 0),
        "Communication": student.get("communication_score", 0),
        "Aptitude": student.get("aptitude_score", 0),
        "Coding": student.get("coding_score", 0),
        "Project experience": min(student.get("project_count", 0) * 20, 100),
    }

    sorted_scores = sorted(scores.items(), key=lambda x: x[1], reverse=True)
    top_strengths = [f"Strong {name}" for name, val in sorted_scores[:3] if val >= 60]
    if not top_strengths:
        top_strengths = ["Building foundational skills across the board"]

    areas_to_improve = [name for name, val in sorted_scores if val < 50][:3]

    return {"top_strengths": top_strengths, "areas_to_improve": areas_to_improve}


# ---------------------------------------------------------------------------
# EARLY SUPPORT / AT-RISK IDENTIFICATION (supportive framing, no negative labels)
# ---------------------------------------------------------------------------

def identify_support_needs(student: dict):
    """
    Identify students who may benefit from additional academic/career support.
    Uses supportive, non-judgmental language as required — never labels a
    student as a "failure" or similar.
    """
    flags = []

    if student.get("aptitude_score", 100) < 40:
        flags.append("You may benefit from additional practice in aptitude problem-solving.")
    if student.get("coding_score", 100) < 40:
        flags.append("You may benefit from additional hands-on coding practice.")
    if student.get("project_count", 5) < 1:
        flags.append("Adding even one small project could meaningfully strengthen your profile.")
    if student.get("communication_score", 100) < 40:
        flags.append("You may benefit from communication practice, such as mock interviews or group discussions.")

    readiness = calculate_readiness_score(student)
    needs_support = readiness["overall_score"] < 45 or len(flags) >= 2

    return {"needs_support": needs_support, "supportive_messages": flags}


# ---------------------------------------------------------------------------
# RESUME ANALYZER
# ---------------------------------------------------------------------------

def extract_text_from_pdf(file_obj):
    """Extract raw text from an uploaded PDF file object using PyPDF2."""
    try:
        reader = PyPDF2.PdfReader(file_obj)
        text = ""
        for page in reader.pages:
            page_text = page.extract_text()
            if page_text:
                text += page_text + "\n"
        return text
    except Exception as e:
        return ""


def analyze_resume(text: str):
    """
    Analyze resume text: detect skills, sections present, and calculate
    a resume score out of 100 with improvement suggestions.
    """
    if not text or not text.strip():
        return {
            "resume_score": 0,
            "detected_skills": [],
            "sections_found": [],
            "missing_sections": list(RESUME_SECTION_KEYWORDS.keys()),
            "suggestions": ["We couldn't read any text from this file. Try uploading a text-based PDF (not a scanned image)."],
        }

    lower_text = text.lower()

    detected_skills = [kw.title() for kw in RESUME_SKILL_KEYWORDS if kw in lower_text]

    sections_found = []
    missing_sections = []
    for section, keywords in RESUME_SECTION_KEYWORDS.items():
        if any(kw in lower_text for kw in keywords):
            sections_found.append(section)
        else:
            missing_sections.append(section)

    # Simple, transparent scoring formula (documented so it's not a black box)
    skill_points = min(len(detected_skills) * 4, 50)          # up to 50 pts for skills
    section_points = len(sections_found) * 10                  # up to 50 pts for sections (5 sections)
    resume_score = min(skill_points + section_points, 100)

    suggestions = []
    if missing_sections:
        suggestions.append(f"Consider adding a clear section for: {', '.join(missing_sections)}.")
    if len(detected_skills) < 5:
        suggestions.append("List more specific technical skills and tools by name (e.g., Python, SQL, Pandas).")
    if "project" not in lower_text:
        suggestions.append("Add at least one project with a short description and tools used.")
    if not re.search(r"[\w.+-]+@[\w-]+\.[\w.-]+", text):
        suggestions.append("Make sure your email address is clearly visible near the top.")
    if not suggestions:
        suggestions.append("Your resume covers the key sections well — keep it updated as you add new projects.")

    return {
        "resume_score": resume_score,
        "detected_skills": detected_skills,
        "sections_found": sections_found,
        "missing_sections": missing_sections,
        "suggestions": suggestions,
    }


# ---------------------------------------------------------------------------
# COMPANY SKILL MATCHING
# ---------------------------------------------------------------------------

def load_company_data():
    path = os.path.join(DATA_DIR, "company_skills.csv")
    if not os.path.exists(path):
        from utils.dataset_generator import generate_company_dataset
        generate_company_dataset()
    return pd.read_csv(path)


def company_match(student: dict, company_name: str, threshold=50):
    """
    Compare a student's skills + communication/aptitude against a company's
    commonly expected skills. Educational skill-match only -- not an official
    hiring requirement (this is clearly labeled in the UI as well).
    """
    companies_df = load_company_data()
    row = companies_df[companies_df["company_name"] == company_name]
    if row.empty:
        return None

    required_skills = [s.strip() for s in row.iloc[0]["required_skills"].split(",")]
    known_skills = get_student_known_skills(student, threshold)
    known_lower = {s.lower() for s in known_skills}

    # Communication and Aptitude count as "skills" if the company marks them important
    have = []
    missing = []
    for skill in required_skills:
        skill_lower = skill.lower()
        if skill_lower == "communication":
            if student.get("communication_score", 0) >= threshold:
                have.append(skill)
            else:
                missing.append(skill)
        elif skill_lower == "aptitude":
            if student.get("aptitude_score", 0) >= threshold:
                have.append(skill)
            else:
                missing.append(skill)
        elif skill_lower in known_lower:
            have.append(skill)
        else:
            missing.append(skill)

    match_score = round((len(have) / len(required_skills)) * 100, 1) if required_skills else 0

    return {
        "company_name": company_name,
        "job_roles": row.iloc[0]["common_job_roles"],
        "match_score": match_score,
        "have": have,
        "missing": missing,
        "aptitude_importance": row.iloc[0]["aptitude_importance"],
        "communication_importance": row.iloc[0]["communication_importance"],
    }


# ---------------------------------------------------------------------------
# INTERVIEW QUESTION BANK
# ---------------------------------------------------------------------------

INTERVIEW_QUESTIONS = {
    "Data Scientist": {
        "Technical": [
            "What is overfitting and how can you prevent it?",
            "Explain the difference between supervised and unsupervised learning.",
            "What is the difference between classification and regression?",
            "What is a confusion matrix and what does it tell you?",
            "Explain bias-variance tradeoff.",
        ],
        "Python": [
            "What is the difference between a list and a tuple in Python?",
            "How does a Python dictionary work internally?",
            "What are Python decorators?",
        ],
        "SQL": [
            "What is the difference between INNER JOIN and LEFT JOIN?",
            "How would you find duplicate rows in a table?",
            "What is a primary key vs a foreign key?",
        ],
        "HR": [
            "Tell me about yourself.",
            "Why do you want to work in data science?",
            "Describe a time you solved a difficult problem.",
        ],
        "Project-based": [
            "Walk me through your most challenging project.",
            "What would you do differently if you rebuilt your project today?",
        ],
    },
    "Software Developer": {
        "Technical": [
            "Explain the difference between abstraction and encapsulation.",
            "What is the time complexity of binary search?",
            "What is a hash table and how does it work?",
        ],
        "Python": [
            "What are Python generators used for?",
            "Explain exception handling in Python.",
        ],
        "SQL": [
            "What is normalization in databases?",
            "Write a query to find the second highest salary from a table.",
        ],
        "HR": [
            "Tell me about yourself.",
            "How do you handle tight deadlines?",
        ],
        "Project-based": [
            "Explain the architecture of your favorite project.",
            "How did you handle bugs or errors during development?",
        ],
    },
}

# Default question set for any role not explicitly listed above
DEFAULT_QUESTIONS = INTERVIEW_QUESTIONS["Data Scientist"]


def get_interview_questions(role_name: str):
    return INTERVIEW_QUESTIONS.get(role_name, DEFAULT_QUESTIONS)
