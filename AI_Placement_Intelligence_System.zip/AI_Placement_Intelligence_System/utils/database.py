"""
database.py
------------
Handles all SQLite database operations for the AI Placement Intelligence System.

Tables created:
    users               -> login credentials + role (student/admin)
    student_profiles     -> full student profile data
    learning_progress    -> tracks which skills a student has learned
    placement_predictions -> stores each ML prediction made for a student
    progress_history      -> stores readiness score snapshots over time

All functions in this file are safe to call even if the database file
does not exist yet -- init_db() will create it automatically.
"""

import sqlite3
import os
import bcrypt
from datetime import datetime

# Path to the SQLite database file. Using os.path so it works on any OS.
DB_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "database")
DB_PATH = os.path.join(DB_DIR, "placement_system.db")


def get_connection():
    """Return a new SQLite connection. Creates the database folder if missing."""
    os.makedirs(DB_DIR, exist_ok=True)
    conn = sqlite3.connect(DB_PATH, check_same_thread=False)
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def init_db():
    """
    Create all required tables if they do not already exist,
    and create a default admin account (username: admin, password: admin123)
    so the app is usable immediately on first run.
    """
    conn = get_connection()
    cur = conn.cursor()

    cur.execute("""
        CREATE TABLE IF NOT EXISTS users (
            user_id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            role TEXT NOT NULL CHECK(role IN ('student', 'admin')),
            created_at TEXT NOT NULL
        )
    """)

    cur.execute("""
        CREATE TABLE IF NOT EXISTS student_profiles (
            student_id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER UNIQUE,
            name TEXT,
            roll_number TEXT,
            branch TEXT,
            year INTEGER,
            cgpa REAL,
            college TEXT,
            email TEXT,
            phone TEXT,
            python_skill INTEGER DEFAULT 0,
            java_skill INTEGER DEFAULT 0,
            sql_skill INTEGER DEFAULT 0,
            dsa_skill INTEGER DEFAULT 0,
            machine_learning_skill INTEGER DEFAULT 0,
            soft_skills TEXT,
            certifications TEXT,
            project_count INTEGER DEFAULT 0,
            internship_experience INTEGER DEFAULT 0,
            aptitude_score INTEGER DEFAULT 0,
            communication_score INTEGER DEFAULT 0,
            coding_score INTEGER DEFAULT 0,
            attendance_percentage REAL DEFAULT 0,
            preferred_domain TEXT,
            updated_at TEXT,
            FOREIGN KEY (user_id) REFERENCES users(user_id)
        )
    """)

    cur.execute("""
        CREATE TABLE IF NOT EXISTS learning_progress (
            progress_id INTEGER PRIMARY KEY AUTOINCREMENT,
            student_id INTEGER,
            skill_name TEXT,
            status TEXT CHECK(status IN ('Not Started', 'In Progress', 'Completed')) DEFAULT 'Not Started',
            updated_at TEXT,
            FOREIGN KEY (student_id) REFERENCES student_profiles(student_id)
        )
    """)

    cur.execute("""
        CREATE TABLE IF NOT EXISTS placement_predictions (
            prediction_id INTEGER PRIMARY KEY AUTOINCREMENT,
            student_id INTEGER,
            readiness_score REAL,
            placement_probability REAL,
            risk_level TEXT,
            created_at TEXT,
            FOREIGN KEY (student_id) REFERENCES student_profiles(student_id)
        )
    """)

    cur.execute("""
        CREATE TABLE IF NOT EXISTS progress_history (
            history_id INTEGER PRIMARY KEY AUTOINCREMENT,
            student_id INTEGER,
            readiness_score REAL,
            recorded_at TEXT,
            FOREIGN KEY (student_id) REFERENCES student_profiles(student_id)
        )
    """)

    cur.execute("""
        CREATE TABLE IF NOT EXISTS interview_progress (
            item_id INTEGER PRIMARY KEY AUTOINCREMENT,
            student_id INTEGER,
            question TEXT,
            status TEXT CHECK(status IN ('Practiced', 'Need Improvement')) DEFAULT 'Need Improvement',
            updated_at TEXT,
            FOREIGN KEY (student_id) REFERENCES student_profiles(student_id)
        )
    """)

    conn.commit()

    # Create a default admin account if one does not already exist
    cur.execute("SELECT * FROM users WHERE username = ?", ("admin",))
    if cur.fetchone() is None:
        password_hash = bcrypt.hashpw("admin123".encode("utf-8"), bcrypt.gensalt()).decode("utf-8")
        cur.execute(
            "INSERT INTO users (username, password_hash, role, created_at) VALUES (?, ?, ?, ?)",
            ("admin", password_hash, "admin", datetime.now().isoformat()),
        )
        conn.commit()

    conn.close()


# ---------------------------------------------------------------------------
# USER AUTH FUNCTIONS
# ---------------------------------------------------------------------------

def create_user(username, password, role="student"):
    """Create a new user. Returns (success: bool, message: str)."""
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("SELECT * FROM users WHERE username = ?", (username,))
    if cur.fetchone() is not None:
        conn.close()
        return False, "Username already exists."

    password_hash = bcrypt.hashpw(password.encode("utf-8"), bcrypt.gensalt()).decode("utf-8")
    cur.execute(
        "INSERT INTO users (username, password_hash, role, created_at) VALUES (?, ?, ?, ?)",
        (username, password_hash, role, datetime.now().isoformat()),
    )
    conn.commit()
    conn.close()
    return True, "Account created successfully."


def verify_user(username, password):
    """Verify login credentials. Returns user dict if valid, else None."""
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("SELECT user_id, username, password_hash, role FROM users WHERE username = ?", (username,))
    row = cur.fetchone()
    conn.close()

    if row is None:
        return None

    user_id, uname, password_hash, role = row
    if bcrypt.checkpw(password.encode("utf-8"), password_hash.encode("utf-8")):
        return {"user_id": user_id, "username": uname, "role": role}
    return None


# ---------------------------------------------------------------------------
# STUDENT PROFILE FUNCTIONS
# ---------------------------------------------------------------------------

def get_student_by_user_id(user_id):
    """Return the student profile row (as dict) for a given user_id, or None."""
    conn = get_connection()
    conn.row_factory = sqlite3.Row
    cur = conn.cursor()
    cur.execute("SELECT * FROM student_profiles WHERE user_id = ?", (user_id,))
    row = cur.fetchone()
    conn.close()
    return dict(row) if row else None


def upsert_student_profile(user_id, profile: dict):
    """Insert or update a student's profile."""
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("SELECT student_id FROM student_profiles WHERE user_id = ?", (user_id,))
    existing = cur.fetchone()

    fields = [
        "name", "roll_number", "branch", "year", "cgpa", "college", "email", "phone",
        "python_skill", "java_skill", "sql_skill", "dsa_skill", "machine_learning_skill",
        "soft_skills", "certifications", "project_count", "internship_experience",
        "aptitude_score", "communication_score", "coding_score", "attendance_percentage",
        "preferred_domain",
    ]
    values = [profile.get(f) for f in fields]

    if existing:
        set_clause = ", ".join([f"{f} = ?" for f in fields])
        cur.execute(
            f"UPDATE student_profiles SET {set_clause}, updated_at = ? WHERE user_id = ?",
            values + [datetime.now().isoformat(), user_id],
        )
        student_id = existing[0]
    else:
        cols = ", ".join(fields)
        placeholders = ", ".join(["?"] * len(fields))
        cur.execute(
            f"INSERT INTO student_profiles (user_id, {cols}, updated_at) VALUES (?, {placeholders}, ?)",
            [user_id] + values + [datetime.now().isoformat()],
        )
        student_id = cur.lastrowid

    conn.commit()
    conn.close()
    return student_id


def get_all_students():
    """Return all student profiles as a list of dicts (used by Admin Dashboard)."""
    conn = get_connection()
    conn.row_factory = sqlite3.Row
    cur = conn.cursor()
    cur.execute("SELECT * FROM student_profiles")
    rows = cur.fetchall()
    conn.close()
    return [dict(r) for r in rows]


# ---------------------------------------------------------------------------
# PREDICTIONS + PROGRESS HISTORY
# ---------------------------------------------------------------------------

def save_prediction(student_id, readiness_score, placement_probability, risk_level):
    conn = get_connection()
    cur = conn.cursor()
    cur.execute(
        "INSERT INTO placement_predictions (student_id, readiness_score, placement_probability, risk_level, created_at) VALUES (?, ?, ?, ?, ?)",
        (student_id, readiness_score, placement_probability, risk_level, datetime.now().isoformat()),
    )
    cur.execute(
        "INSERT INTO progress_history (student_id, readiness_score, recorded_at) VALUES (?, ?, ?)",
        (student_id, readiness_score, datetime.now().isoformat()),
    )
    conn.commit()
    conn.close()


def get_progress_history(student_id):
    conn = get_connection()
    conn.row_factory = sqlite3.Row
    cur = conn.cursor()
    cur.execute("SELECT * FROM progress_history WHERE student_id = ? ORDER BY recorded_at ASC", (student_id,))
    rows = cur.fetchall()
    conn.close()
    return [dict(r) for r in rows]


# ---------------------------------------------------------------------------
# LEARNING ROADMAP PROGRESS
# ---------------------------------------------------------------------------

def set_skill_status(student_id, skill_name, status):
    conn = get_connection()
    cur = conn.cursor()
    cur.execute(
        "SELECT progress_id FROM learning_progress WHERE student_id = ? AND skill_name = ?",
        (student_id, skill_name),
    )
    existing = cur.fetchone()
    if existing:
        cur.execute(
            "UPDATE learning_progress SET status = ?, updated_at = ? WHERE progress_id = ?",
            (status, datetime.now().isoformat(), existing[0]),
        )
    else:
        cur.execute(
            "INSERT INTO learning_progress (student_id, skill_name, status, updated_at) VALUES (?, ?, ?, ?)",
            (student_id, skill_name, status, datetime.now().isoformat()),
        )
    conn.commit()
    conn.close()


def get_skill_statuses(student_id):
    """Return a dict of {skill_name: status} for the given student."""
    conn = get_connection()
    conn.row_factory = sqlite3.Row
    cur = conn.cursor()
    cur.execute("SELECT skill_name, status FROM learning_progress WHERE student_id = ?", (student_id,))
    rows = cur.fetchall()
    conn.close()
    return {r["skill_name"]: r["status"] for r in rows}


# ---------------------------------------------------------------------------
# INTERVIEW PREP PROGRESS
# ---------------------------------------------------------------------------

def set_interview_status(student_id, question, status):
    conn = get_connection()
    cur = conn.cursor()
    cur.execute(
        "SELECT item_id FROM interview_progress WHERE student_id = ? AND question = ?",
        (student_id, question),
    )
    existing = cur.fetchone()
    if existing:
        cur.execute(
            "UPDATE interview_progress SET status = ?, updated_at = ? WHERE item_id = ?",
            (status, datetime.now().isoformat(), existing[0]),
        )
    else:
        cur.execute(
            "INSERT INTO interview_progress (student_id, question, status, updated_at) VALUES (?, ?, ?, ?)",
            (student_id, question, status, datetime.now().isoformat()),
        )
    conn.commit()
    conn.close()


def get_interview_statuses(student_id):
    conn = get_connection()
    conn.row_factory = sqlite3.Row
    cur = conn.cursor()
    cur.execute("SELECT question, status FROM interview_progress WHERE student_id = ?", (student_id,))
    rows = cur.fetchall()
    conn.close()
    return {r["question"]: r["status"] for r in rows}
