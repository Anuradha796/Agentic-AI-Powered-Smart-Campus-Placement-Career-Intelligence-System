"""
app.py
------
Main entry point for the AI-Powered Smart Campus Placement & Career
Intelligence System. Handles the Home page, login, and registration.

Run with:  streamlit run app.py
"""

import streamlit as st
import os
import sys

# Make sure "utils" is importable regardless of where streamlit is launched from
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from utils.database import init_db, create_user, verify_user
from utils.dataset_generator import ensure_datasets_exist

st.set_page_config(
    page_title="AI Placement Intelligence System",
    page_icon="🎓",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ---------------------------------------------------------------------------
# STARTUP: initialize database + ensure datasets exist (safe to call every run)
# ---------------------------------------------------------------------------
try:
    init_db()
    ensure_datasets_exist()
except Exception as e:
    st.error(f"Startup error: {e}")

# ---------------------------------------------------------------------------
# SESSION STATE DEFAULTS
# ---------------------------------------------------------------------------
if "logged_in" not in st.session_state:
    st.session_state.logged_in = False
if "user" not in st.session_state:
    st.session_state.user = None


def login_form():
    st.subheader("🔐 Login")
    with st.form("login_form"):
        username = st.text_input("Username")
        password = st.text_input("Password", type="password")
        submitted = st.form_submit_button("Login")

    if submitted:
        if not username or not password:
            st.warning("Please enter both username and password.")
            return
        user = verify_user(username, password)
        if user:
            st.session_state.logged_in = True
            st.session_state.user = user
            st.success(f"Welcome back, {user['username']}!")
            st.rerun()
        else:
            st.error("Invalid username or password.")

    st.caption("Default admin login — username: `admin`, password: `admin123`")


def register_form():
    st.subheader("📝 Create a Student Account")
    with st.form("register_form"):
        username = st.text_input("Choose a username")
        password = st.text_input("Choose a password", type="password")
        confirm = st.text_input("Confirm password", type="password")
        submitted = st.form_submit_button("Create Account")

    if submitted:
        if not username or not password:
            st.warning("Please fill in all fields.")
        elif password != confirm:
            st.error("Passwords do not match.")
        elif len(password) < 4:
            st.error("Password should be at least 4 characters.")
        else:
            success, message = create_user(username, password, role="student")
            if success:
                st.success(message + " You can now log in from the Login tab.")
            else:
                st.error(message)


def show_home_content():
    st.title("🎓 AI-Powered Smart Campus Placement & Career Intelligence System")
    st.markdown("##### Understand Your Skills. Discover Your Career. Improve Your Placement Readiness.")
    st.divider()

    cols = st.columns(3)
    features = [
        ("📊", "Placement Prediction", "ML-powered probability of placement based on your live profile."),
        ("🎯", "Career Recommendations", "Discover roles that best match your current skills."),
        ("🧠", "Skill Gap Analysis", "See exactly which skills separate you from your target role."),
        ("📚", "Learning Roadmap", "A personalized, trackable roadmap for missing skills."),
        ("📄", "Resume Analysis", "Upload your resume and get an instant score + suggestions."),
        ("🏢", "Company Insights", "Educational skill-match against common recruiter profiles."),
    ]
    for i, (icon, title, desc) in enumerate(features):
        with cols[i % 3]:
            st.markdown(f"### {icon} {title}")
            st.write(desc)
            st.write("")

    st.divider()
    st.info("👈 Use the sidebar to log in and navigate through the app's pages.")


# ---------------------------------------------------------------------------
# MAIN LAYOUT
# ---------------------------------------------------------------------------
if not st.session_state.logged_in:
    show_home_content()
    st.divider()
    tab1, tab2 = st.tabs(["Login", "Register (Student)"])
    with tab1:
        login_form()
    with tab2:
        register_form()
else:
    user = st.session_state.user
    st.sidebar.success(f"Logged in as **{user['username']}** ({user['role']})")
    if st.sidebar.button("Logout"):
        st.session_state.logged_in = False
        st.session_state.user = None
        st.rerun()

    show_home_content()

    if user["role"] == "student":
        st.success("Head to **Student Profile** in the sidebar to get started, then explore the other pages.")
    else:
        st.success("Head to **Admin Dashboard** in the sidebar to view placement analytics.")
