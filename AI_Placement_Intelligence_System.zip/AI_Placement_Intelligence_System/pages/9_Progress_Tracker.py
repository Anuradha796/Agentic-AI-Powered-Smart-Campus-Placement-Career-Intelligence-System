import streamlit as st
import sys, os
import plotly.express as px
import pandas as pd

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from utils.database import get_student_by_user_id, get_progress_history, get_skill_statuses

st.set_page_config(page_title="Progress Tracker", page_icon="📈", layout="wide")
st.title("📈 Progress Tracker")

if not st.session_state.get("logged_in"):
    st.warning("Please log in from the Home page first.")
    st.stop()

user = st.session_state.user
if user["role"] != "student":
    st.info("This page is for student accounts.")
    st.stop()

student = get_student_by_user_id(user["user_id"])
if not student:
    st.warning("Please complete your Student Profile first.")
    st.stop()

history = get_progress_history(student["student_id"])

if not history:
    st.info("No prediction history yet. Run a prediction from the **Placement Predictor** page to start tracking your progress.")
else:
    df = pd.DataFrame(history)
    df["recorded_at"] = pd.to_datetime(df["recorded_at"])

    fig = px.line(
        df, x="recorded_at", y="readiness_score", markers=True,
        title="Placement Readiness Score Over Time",
        labels={"recorded_at": "Date", "readiness_score": "Readiness Score"},
    )
    st.plotly_chart(fig, use_container_width=True)

    col1, col2 = st.columns(2)
    with col1:
        st.metric("Latest Readiness Score", f"{df['readiness_score'].iloc[-1]}")
    with col2:
        if len(df) > 1:
            change = round(df["readiness_score"].iloc[-1] - df["readiness_score"].iloc[0], 1)
            st.metric("Improvement Since First Check", f"{change:+}")
        else:
            st.metric("Improvement Since First Check", "N/A")

st.divider()
st.subheader("Skills Completed")
skill_statuses = get_skill_statuses(student["student_id"])
if skill_statuses:
    status_df = pd.DataFrame(list(skill_statuses.items()), columns=["Skill", "Status"])
    fig2 = px.pie(status_df, names="Status", title="Learning Roadmap Status Breakdown")
    st.plotly_chart(fig2, use_container_width=True)
    st.dataframe(status_df, use_container_width=True, hide_index=True)
else:
    st.info("No roadmap progress recorded yet. Visit **Learning Roadmap** to get started.")
