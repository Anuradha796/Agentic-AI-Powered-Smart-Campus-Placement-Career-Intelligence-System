import streamlit as st
import sys, os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from utils.skill_analysis import extract_text_from_pdf, analyze_resume

st.set_page_config(page_title="Resume Analyzer", page_icon="📄", layout="wide")
st.title("📄 Resume Analyzer")

if not st.session_state.get("logged_in"):
    st.warning("Please log in from the Home page first.")
    st.stop()

st.write("Upload your resume as a PDF to get an instant score and improvement suggestions.")

uploaded_file = st.file_uploader("Upload Resume (PDF only)", type=["pdf"])

if uploaded_file is not None:
    try:
        text = extract_text_from_pdf(uploaded_file)
        result = analyze_resume(text)

        st.subheader(f"Resume Score: {result['resume_score']}/100")
        st.progress(min(result["resume_score"], 100) / 100)

        col1, col2 = st.columns(2)
        with col1:
            st.markdown("### Sections Found")
            for s in result["sections_found"]:
                st.write(f"✅ {s}")
            if result["missing_sections"]:
                st.markdown("### Sections Missing")
                for s in result["missing_sections"]:
                    st.write(f"❌ {s}")

        with col2:
            st.markdown("### Skills Detected")
            if result["detected_skills"]:
                st.write(", ".join(result["detected_skills"]))
            else:
                st.write("No recognizable technical skill keywords found.")

        st.divider()
        st.markdown("### 💡 Improvement Suggestions")
        for s in result["suggestions"]:
            st.write(f"- {s}")

    except Exception as e:
        st.error(f"Could not process this file: {e}")
else:
    st.info("Waiting for a PDF upload.")
