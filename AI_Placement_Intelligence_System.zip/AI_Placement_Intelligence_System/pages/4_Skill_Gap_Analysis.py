import streamlit as st
import sys, os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from utils.database import get_student_by_user_id
from utils.skill_analysis import skill_gap_for_role, load_job_roles

st.set_page_config(page_title="Skill Gap Analysis", page_icon="🧠", layout="wide")
st.title("🧠 Skill Gap Analysis")

if not st.session_state.get("logged_in"):
    st.warning("Please log in from the Home page first.")
    st.stop()

user = st.session_state.user
if user["role"] != "student":
    st.info("This page is for student accounts.")
    st.stop()

student = get_student_by_user_id(user["user_id"])
if not student:
    st.warning("Please complete your Student Profile first.")
    st.stop()

roles_df = load_job_roles()
role_name = st.selectbox("Choose a career role to compare against", roles_df["role"].tolist())

gap = skill_gap_for_role(student, role_name)

st.subheader(f"Skill Match for {role_name}: {gap['match_percentage']}%")
st.progress(min(int(gap["match_percentage"]), 100) / 100)

col1, col2 = st.columns(2)
with col1:
    st.markdown("### ✅ Skills Already Available")
    if gap["available"]:
        for s in gap["available"]:
            st.write(f"- {s}")
    else:
        st.write("None yet for this role — see the missing skills to start building them.")

with col2:
    st.markdown("### ❌ Skills Missing")
    if gap["missing"]:
        for s in gap["missing"]:
            st.write(f"- {s}")
    else:
        st.success("You already cover every required skill for this role!")

st.divider()
st.info("Head to **Learning Roadmap** to turn your missing skills into a step-by-step study plan.")
