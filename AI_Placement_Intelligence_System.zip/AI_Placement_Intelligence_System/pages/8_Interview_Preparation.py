import streamlit as st
import sys, os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from utils.database import get_student_by_user_id, set_interview_status, get_interview_statuses
from utils.skill_analysis import get_interview_questions, INTERVIEW_QUESTIONS

st.set_page_config(page_title="Interview Preparation", page_icon="🎤", layout="wide")
st.title("🎤 Mock Interview Preparation")

if not st.session_state.get("logged_in"):
    st.warning("Please log in from the Home page first.")
    st.stop()

user = st.session_state.user
if user["role"] != "student":
    st.info("This page is for student accounts.")
    st.stop()

student = get_student_by_user_id(user["user_id"])
if not student:
    st.warning("Please complete your Student Profile first.")
    st.stop()

role_options = list(INTERVIEW_QUESTIONS.keys()) + ["Other / General"]
default_role = student.get("preferred_domain") if student.get("preferred_domain") in INTERVIEW_QUESTIONS else role_options[0]
role_name = st.selectbox("Select your target role", role_options, index=role_options.index(default_role))

questions_by_category = get_interview_questions(role_name if role_name != "Other / General" else "Data Scientist")
statuses = get_interview_statuses(student["student_id"])

practiced_count = 0
total_count = 0

for category, questions in questions_by_category.items():
    st.markdown(f"### {category} Questions")
    for q in questions:
        total_count += 1
        current_status = statuses.get(q, "Need Improvement")
        if current_status == "Practiced":
            practiced_count += 1

        col1, col2 = st.columns([4, 1])
        with col1:
            st.write(q)
        with col2:
            new_status = st.selectbox(
                "Status", ["Need Improvement", "Practiced"],
                index=["Need Improvement", "Practiced"].index(current_status),
                key=f"iq_{category}_{q}", label_visibility="collapsed",
            )
            if new_status != current_status:
                set_interview_status(student["student_id"], q, new_status)
                st.rerun()

st.divider()
st.metric("Interview Prep Progress", f"{practiced_count}/{total_count} questions practiced")
