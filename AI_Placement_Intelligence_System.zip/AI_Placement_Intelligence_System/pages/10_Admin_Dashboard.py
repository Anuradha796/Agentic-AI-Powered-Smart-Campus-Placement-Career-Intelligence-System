import streamlit as st
import sys, os
import pandas as pd
import plotly.express as px

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from utils.database import get_all_students
from utils.skill_analysis import calculate_readiness_score, identify_support_needs

st.set_page_config(page_title="Admin Dashboard", page_icon="👨‍💼", layout="wide")
st.title("👨‍💼 Admin Analytics Dashboard")

if not st.session_state.get("logged_in"):
    st.warning("Please log in from the Home page first.")
    st.stop()

user = st.session_state.user
if user["role"] != "admin":
    st.info("This page is for admin / placement officer accounts only.")
    st.stop()

students = get_all_students()

if not students:
    st.info("No student profiles have been created yet.")
    st.stop()

# Compute readiness score + support-need flag for every student
rows = []
for s in students:
    readiness = calculate_readiness_score(s)
    support = identify_support_needs(s)
    rows.append({
        "Name": s.get("name") or "—",
        "Branch": s.get("branch") or "—",
        "Year": s.get("year"),
        "CGPA": s.get("cgpa"),
        "Readiness Score": readiness["overall_score"],
        "Preferred Domain": s.get("preferred_domain") or "—",
        "Needs Support": "Yes" if support["needs_support"] else "No",
    })

df = pd.DataFrame(rows)

# Top-level metrics
col1, col2, col3, col4 = st.columns(4)
with col1:
    st.metric("Total Students", len(df))
with col2:
    st.metric("Average Readiness Score", round(df["Readiness Score"].mean(), 1))
with col3:
    st.metric("Students Needing Support", (df["Needs Support"] == "Yes").sum())
with col4:
    most_common_domain = df["Preferred Domain"].mode().iloc[0] if not df["Preferred Domain"].empty else "—"
    st.metric("Most Popular Domain", most_common_domain)

st.divider()

col_a, col_b = st.columns(2)
with col_a:
    st.markdown("### Branch-wise Average Readiness")
    branch_avg = df.groupby("Branch")["Readiness Score"].mean().reset_index()
    fig1 = px.bar(branch_avg, x="Branch", y="Readiness Score", color="Branch")
    st.plotly_chart(fig1, use_container_width=True)

with col_b:
    st.markdown("### Career Domain Distribution")
    domain_counts = df["Preferred Domain"].value_counts().reset_index()
    domain_counts.columns = ["Domain", "Count"]
    fig2 = px.pie(domain_counts, names="Domain", values="Count")
    st.plotly_chart(fig2, use_container_width=True)

col_c, col_d = st.columns(2)
with col_c:
    st.markdown("### Readiness Score Distribution")
    fig3 = px.histogram(df, x="Readiness Score", nbins=20)
    st.plotly_chart(fig3, use_container_width=True)

with col_d:
    st.markdown("### Year-wise Student Count")
    year_counts = df["Year"].value_counts().reset_index()
    year_counts.columns = ["Year", "Count"]
    fig4 = px.bar(year_counts.sort_values("Year"), x="Year", y="Count")
    st.plotly_chart(fig4, use_container_width=True)

st.divider()
st.markdown("### Students Who May Benefit from Additional Support")
support_df = df[df["Needs Support"] == "Yes"]
if support_df.empty:
    st.success("No students currently flagged for additional support.")
else:
    st.dataframe(support_df, use_container_width=True, hide_index=True)

st.divider()
st.markdown("### Full Student Table")
st.dataframe(df, use_container_width=True, hide_index=True)

csv = df.to_csv(index=False).encode("utf-8")
st.download_button("📥 Export Report as CSV", data=csv, file_name="placement_report.csv", mime="text/csv")
