import streamlit as st
import sys, os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from utils.database import get_student_by_user_id, upsert_student_profile

st.set_page_config(page_title="Student Profile", page_icon="👤", layout="wide")
st.title("👤 Student Profile")

if not st.session_state.get("logged_in"):
    st.warning("Please log in from the Home page first.")
    st.stop()

user = st.session_state.user
if user["role"] != "student":
    st.info("This page is for student accounts. Log in as a student to build a profile.")
    st.stop()

existing = get_student_by_user_id(user["user_id"]) or {}

st.write("Fill in your details below. This profile powers every other feature in the app.")

with st.form("profile_form"):
    col1, col2 = st.columns(2)
    with col1:
        name = st.text_input("Full Name", value=existing.get("name", ""))
        roll_number = st.text_input("Roll Number", value=existing.get("roll_number", ""))
        branch = st.selectbox(
            "Branch",
            ["CSE", "CSE-DS", "IT", "ECE", "EEE", "MECH"],
            index=["CSE", "CSE-DS", "IT", "ECE", "EEE", "MECH"].index(existing["branch"]) if existing.get("branch") in ["CSE", "CSE-DS", "IT", "ECE", "EEE", "MECH"] else 0,
        )
        year = st.selectbox("Year", [1, 2, 3, 4], index=(existing.get("year", 1) - 1) if existing.get("year") else 0)
        cgpa = st.number_input("CGPA", min_value=0.0, max_value=10.0, value=float(existing.get("cgpa") or 7.0), step=0.01)
        college = st.text_input("College", value=existing.get("college", ""))
        email = st.text_input("Email", value=existing.get("email", ""))
        phone = st.text_input("Phone Number", value=existing.get("phone", ""))

    with col2:
        python_skill = st.slider("Python Skill (0-100)", 0, 100, int(existing.get("python_skill") or 0))
        java_skill = st.slider("Java Skill (0-100)", 0, 100, int(existing.get("java_skill") or 0))
        sql_skill = st.slider("SQL Skill (0-100)", 0, 100, int(existing.get("sql_skill") or 0))
        dsa_skill = st.slider("DSA Skill (0-100)", 0, 100, int(existing.get("dsa_skill") or 0))
        ml_skill = st.slider("Machine Learning Skill (0-100)", 0, 100, int(existing.get("machine_learning_skill") or 0))
        soft_skills = st.text_input("Soft Skills (comma separated)", value=existing.get("soft_skills", ""))
        certifications = st.text_area("Certifications (comma separated)", value=existing.get("certifications", ""))

    col3, col4, col5 = st.columns(3)
    with col3:
        project_count = st.number_input("Number of Projects", min_value=0, max_value=20, value=int(existing.get("project_count") or 0))
        aptitude_score = st.slider("Aptitude Score (0-100)", 0, 100, int(existing.get("aptitude_score") or 0))
    with col4:
        internship_experience = st.selectbox("Internship Experience", ["No", "Yes"], index=1 if existing.get("internship_experience") else 0)
        communication_score = st.slider("Communication Score (0-100)", 0, 100, int(existing.get("communication_score") or 0))
    with col5:
        attendance_percentage = st.number_input("Attendance %", min_value=0.0, max_value=100.0, value=float(existing.get("attendance_percentage") or 75.0))
        coding_score = st.slider("Coding Score (0-100)", 0, 100, int(existing.get("coding_score") or 0))

    preferred_domain = st.selectbox(
        "Preferred Career Domain",
        ["Data Analyst", "Data Scientist", "Machine Learning Engineer", "Data Engineer",
         "Software Developer", "Python Developer", "Business Analyst", "AI Engineer",
         "Cloud Engineer", "Cybersecurity Analyst"],
        index=0,
    )

    submitted = st.form_submit_button("Save Profile", use_container_width=True)

if submitted:
    profile = {
        "name": name, "roll_number": roll_number, "branch": branch, "year": year, "cgpa": cgpa,
        "college": college, "email": email, "phone": phone,
        "python_skill": python_skill, "java_skill": java_skill, "sql_skill": sql_skill,
        "dsa_skill": dsa_skill, "machine_learning_skill": ml_skill,
        "soft_skills": soft_skills, "certifications": certifications,
        "project_count": project_count, "internship_experience": 1 if internship_experience == "Yes" else 0,
        "aptitude_score": aptitude_score, "communication_score": communication_score,
        "coding_score": coding_score, "attendance_percentage": attendance_percentage,
        "preferred_domain": preferred_domain,
    }
    try:
        upsert_student_profile(user["user_id"], profile)
        st.success("Profile saved successfully! Explore the other pages from the sidebar.")
    except Exception as e:
        st.error(f"Could not save profile: {e}")
