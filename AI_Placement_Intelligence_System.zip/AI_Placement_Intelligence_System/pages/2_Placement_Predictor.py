import streamlit as st
import sys, os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from utils.database import get_student_by_user_id, save_prediction
from utils.ml_model import predict_placement
from utils.skill_analysis import calculate_readiness_score

st.set_page_config(page_title="Placement Predictor", page_icon="📊", layout="wide")
st.title("📊 Placement Predictor")

if not st.session_state.get("logged_in"):
    st.warning("Please log in from the Home page first.")
    st.stop()

user = st.session_state.user
if user["role"] != "student":
    st.info("This page is for student accounts.")
    st.stop()

student = get_student_by_user_id(user["user_id"])
if not student:
    st.warning("Please complete your Student Profile first.")
    st.stop()

readiness = calculate_readiness_score(student)

st.subheader(f"Placement Readiness Score: {readiness['overall_score']}/100")
st.progress(min(int(readiness["overall_score"]), 100) / 100)

st.markdown("#### Category-wise Scores")
cols = st.columns(len(readiness["category_scores"]))
for col, (cat, score) in zip(cols, readiness["category_scores"].items()):
    with col:
        st.metric(cat, f"{score}")

col_a, col_b = st.columns(2)
with col_a:
    st.markdown("**Strengths**")
    for s in readiness["strengths"]:
        st.write(f"✅ {s}")
with col_b:
    st.markdown("**Areas Needing Improvement**")
    if readiness["improvement_areas"]:
        for a in readiness["improvement_areas"]:
            st.write(f"⚠️ {a}")
    else:
        st.write("No major weak areas detected — nice work!")

st.divider()
st.subheader("🤖 Machine Learning Placement Prediction")

if st.button("Run Placement Prediction", use_container_width=True):
    try:
        # predict_placement can take the raw student profile directly --
        # it derives certification_count from the certifications text itself.
        result = predict_placement(student)

        st.metric("Placement Probability", f"{result['placement_probability']}%")
        st.markdown(f"### {result['probability_label']}")

        if result["risk_level"] == "Low Risk":
            st.success(f"Risk Level: {result['risk_level']}")
        elif result["risk_level"] == "Medium Risk":
            st.warning(f"Risk Level: {result['risk_level']}")
        else:
            st.error(f"Risk Level: {result['risk_level']}")

        save_prediction(
            student["student_id"], readiness["overall_score"],
            result["placement_probability"], result["risk_level"],
        )
        st.caption("This prediction has been saved to your Progress Tracker.")

    except Exception as e:
        st.error(f"Prediction failed: {e}")

with st.expander("ℹ️ How is this prediction made?"):
    st.write(
        "This uses a Machine Learning model (Random Forest / Logistic Regression / "
        "Gradient Boosting — best one selected automatically) trained on a synthetic "
        "dataset of student profiles. It is an educational estimate, not a guarantee."
    )
