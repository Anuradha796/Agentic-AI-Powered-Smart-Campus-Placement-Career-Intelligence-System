import streamlit as st
import sys, os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from utils.database import get_student_by_user_id
from utils.recommendation_engine import recommend_career_roles

st.set_page_config(page_title="Career Recommendations", page_icon="🎯", layout="wide")
st.title("🎯 Career Role Recommendations")

if not st.session_state.get("logged_in"):
    st.warning("Please log in from the Home page first.")
    st.stop()

user = st.session_state.user
if user["role"] != "student":
    st.info("This page is for student accounts.")
    st.stop()

student = get_student_by_user_id(user["user_id"])
if not student:
    st.warning("Please complete your Student Profile first.")
    st.stop()

recommendations = recommend_career_roles(student, top_n=5)

st.write("Based on your current skill profile, here are the roles that best match you:")

for i, rec in enumerate(recommendations, start=1):
    with st.container(border=True):
        st.markdown(f"### {i}. {rec['role']} — {rec['match_percentage']}% Match")
        st.progress(min(int(rec["match_percentage"]), 100) / 100)
        st.write(rec["reason"])
        col1, col2 = st.columns(2)
        with col1:
            st.markdown("**Required Skills**")
            st.write(", ".join(rec["required_skills"]))
        with col2:
            st.markdown("**Your Matching Skills**")
            st.write(", ".join(rec["matched_skills"]) if rec["matched_skills"] else "None yet — see Skill Gap Analysis")
