import streamlit as st
import sys, os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from utils.database import get_student_by_user_id, set_skill_status, get_skill_statuses
from utils.skill_analysis import skill_gap_for_role, load_job_roles

st.set_page_config(page_title="Learning Roadmap", page_icon="📚", layout="wide")
st.title("📚 Personalized Learning Roadmap")

if not st.session_state.get("logged_in"):
    st.warning("Please log in from the Home page first.")
    st.stop()

user = st.session_state.user
if user["role"] != "student":
    st.info("This page is for student accounts.")
    st.stop()

student = get_student_by_user_id(user["user_id"])
if not student:
    st.warning("Please complete your Student Profile first.")
    st.stop()

roles_df = load_job_roles()
role_name = st.selectbox("Build a roadmap for role:", roles_df["role"].tolist())

gap = skill_gap_for_role(student, role_name)
missing_skills = gap["missing"]

if not missing_skills:
    st.success(f"You already meet the required skills for {role_name}. No roadmap needed!")
    st.stop()

# Simple estimated-time and priority logic: earlier missing skills get higher priority
DURATIONS = ["1-2 weeks", "2-3 weeks", "3-4 weeks"]
BEGINNER_RESOURCES = {
    "python": "freeCodeCamp Python course, official Python docs tutorial",
    "sql": "Mode SQL Tutorial, W3Schools SQL",
    "machine learning": "Andrew Ng's Machine Learning course (Coursera), Kaggle Learn",
    "statistics": "Khan Academy Statistics, StatQuest (YouTube)",
    "data visualization": "Kaggle Learn Data Visualization, Plotly docs",
    "cloud": "AWS Cloud Practitioner Essentials (free tier), Azure Fundamentals",
    "dsa": "NeetCode roadmap, GeeksforGeeks DSA",
    "excel": "Microsoft Excel free tutorials, ExcelJet",
    "git": "GitHub's official Git Handbook",
    "etl": "DataCamp ETL basics, freeCodeCamp data engineering",
    "java": "Java Programming MOOC (University of Helsinki)",
    "linux": "Linux Journey, OverTheWire Bandit",
    "networking": "Cisco Networking Basics, Professor Messer",
    "security fundamentals": "TryHackMe free rooms, Cybrary basics",
    "oop": "GeeksforGeeks OOP concepts, freeCodeCamp OOP course",
}

statuses = get_skill_statuses(student["student_id"])

st.write(f"Here is your roadmap for becoming ready for **{role_name}**:")

for i, skill in enumerate(missing_skills):
    priority = "High" if i == 0 else ("Medium" if i == 1 else "Low")
    duration = DURATIONS[min(i, len(DURATIONS) - 1)]
    resource = BEGINNER_RESOURCES.get(skill.lower(), "Search Coursera / freeCodeCamp / official docs")
    current_status = statuses.get(skill, "Not Started")

    with st.container(border=True):
        col1, col2 = st.columns([3, 1])
        with col1:
            st.markdown(f"### {skill}")
            st.write(f"**Priority:** {priority}  |  **Estimated Time:** {duration}")
            st.write(f"**Beginner Resources:** {resource}")
        with col2:
            new_status = st.selectbox(
                "Progress", ["Not Started", "In Progress", "Completed"],
                index=["Not Started", "In Progress", "Completed"].index(current_status),
                key=f"status_{skill}",
            )
            if new_status != current_status:
                set_skill_status(student["student_id"], skill, new_status)
                st.rerun()

st.divider()
completed = sum(1 for s in missing_skills if statuses.get(s) == "Completed")
st.metric("Roadmap Progress", f"{completed}/{len(missing_skills)} skills completed")
