import streamlit as st
import sys, os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from utils.database import get_student_by_user_id
from utils.skill_analysis import company_match, load_company_data

st.set_page_config(page_title="Company Insights", page_icon="🏢", layout="wide")
st.title("🏢 Company Insights")

st.warning(
    "⚠️ **Educational skill-match recommendation system.** The skills listed here are "
    "general, commonly discussed expectations and are **not official hiring requirements** "
    "from these companies. Always check each company's official careers page for accurate, "
    "up-to-date requirements."
)

if not st.session_state.get("logged_in"):
    st.warning("Please log in from the Home page first.")
    st.stop()

user = st.session_state.user
if user["role"] != "student":
    st.info("This page is for student accounts.")
    st.stop()

student = get_student_by_user_id(user["user_id"])
if not student:
    st.warning("Please complete your Student Profile first.")
    st.stop()

companies_df = load_company_data()
company_name = st.selectbox("Choose a company", companies_df["company_name"].tolist())

result = company_match(student, company_name)

if result:
    st.subheader(f"Company Match Score: {result['match_score']}%")
    st.progress(min(int(result["match_score"]), 100) / 100)
    st.write(f"**Common Job Roles:** {result['job_roles']}")

    col1, col2 = st.columns(2)
    with col1:
        st.markdown("### You Have")
        for s in result["have"]:
            st.write(f"✅ {s}")
        if not result["have"]:
            st.write("None of the commonly expected skills yet.")
    with col2:
        st.markdown("### Skills to Improve")
        for s in result["missing"]:
            st.write(f"⚠️ {s}")
        if not result["missing"]:
            st.success("You cover all commonly expected skills for this company profile!")

    st.info(f"To improve your chances for {company_name}, focus on these skills: "
            f"{', '.join(result['missing']) if result['missing'] else 'You are well covered — keep practicing interviews.'}")
else:
    st.error("Company data not found.")
